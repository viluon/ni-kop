# ~\~ language=Python filename=entangled/__init__.py
# ~\~ begin <<lit/entangled-python.md|entangled/__init__.py>>[0]
__version__ = "0.8.1"
# ~\~ end
